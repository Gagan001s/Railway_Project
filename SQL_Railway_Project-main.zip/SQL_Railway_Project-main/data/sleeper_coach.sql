/* INSERT QUERY NO: 1 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
1, 'LB'
);

/* INSERT QUERY NO: 2 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
2, 'MB'
);

/* INSERT QUERY NO: 3 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
3, 'UB'
);

/* INSERT QUERY NO: 4 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
4, 'LB'
);

/* INSERT QUERY NO: 5 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
5, 'MB'
);

/* INSERT QUERY NO: 6 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
6, 'UB'
);

/* INSERT QUERY NO: 7 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
7, 'SL'
);

/* INSERT QUERY NO: 8 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
8, 'SU'
);

/* INSERT QUERY NO: 9 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
9, 'LB'
);

/* INSERT QUERY NO: 10 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
10, 'MB'
);

/* INSERT QUERY NO: 11 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
11, 'UB'
);

/* INSERT QUERY NO: 12 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
12, 'LB'
);

/* INSERT QUERY NO: 13 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
13, 'MB'
);

/* INSERT QUERY NO: 14 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
14, 'UB'
);

/* INSERT QUERY NO: 15 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
15, 'SL'
);

/* INSERT QUERY NO: 16 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
16, 'SU'
);

/* INSERT QUERY NO: 17 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
17, 'LB'
);

/* INSERT QUERY NO: 18 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
18, 'MB'
);

/* INSERT QUERY NO: 19 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
19, 'UB'
);

/* INSERT QUERY NO: 20 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
20, 'LB'
);

/* INSERT QUERY NO: 21 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
21, 'MB'
);

/* INSERT QUERY NO: 22 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
22, 'UB'
);

/* INSERT QUERY NO: 23 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
23, 'SL'
);

/* INSERT QUERY NO: 24 */
INSERT INTO sleeper_coach(seat_number, seat_type)
VALUES
(
24, 'SU'
);

