/* INSERT QUERY NO: 1 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
1, 'LB'
);

/* INSERT QUERY NO: 2 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
2, 'LB'
);

/* INSERT QUERY NO: 3 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
3, 'UB'
);

/* INSERT QUERY NO: 4 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
4, 'UB'
);

/* INSERT QUERY NO: 5 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
5, 'SL'
);

/* INSERT QUERY NO: 6 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
6, 'SU'
);

/* INSERT QUERY NO: 7 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
7, 'LB'
);

/* INSERT QUERY NO: 8 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
8, 'LB'
);

/* INSERT QUERY NO: 9 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
9, 'UB'
);

/* INSERT QUERY NO: 10 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
10, 'UB'
);

/* INSERT QUERY NO: 11 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
11, 'SL'
);

/* INSERT QUERY NO: 12 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
12, 'SU'
);

/* INSERT QUERY NO: 13 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
13, 'LB'
);

/* INSERT QUERY NO: 14 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
14, 'LB'
);

/* INSERT QUERY NO: 15 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
15, 'UB'
);

/* INSERT QUERY NO: 16 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
16, 'UB'
);

/* INSERT QUERY NO: 17 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
17, 'SL'
);

/* INSERT QUERY NO: 18 */
INSERT INTO ac_coach(seat_number, seat_type)
VALUES
(
18, 'SU'
);

