# Railway Reservation System

A Portal for booking railway tickets in multiple types of coaches (SL and AC).

+ Used MySQL as a database for backend.
+ Used Triggers and Stored Procedures for consistency checks on the database.

